package fool;

import javax.swing.*;
import java.util.Map;
import java.util.Objects;

public final class Card {

    public enum Suit {
        CLUB, DIAMOND, HEART, SPADE
    }

    public enum Rank {
        SIX("6"), SEVEN("7"), EIGHT("8"), NINE("9"),
        TEN("10"), JACK("J"), QUEEN("Q"), KING("K"), ACE("A");

        private final String symbol;

        Rank(String symbol) {
            this.symbol = symbol;
        }

        public String getSymbol() {
            return symbol;
        }

        public static Rank fromString(String s) {
            // Добавляем обработку как числовых значений, так и слов
            return switch (s.toUpperCase()) {
                case "6", "SIX" ->
                    SIX;
                case "7", "SEVEN" ->
                    SEVEN;
                case "8", "EIGHT" ->
                    EIGHT;
                case "9", "NINE" ->
                    NINE;
                case "10", "TEN" ->
                    TEN;
                case "J", "JACK" ->
                    JACK;
                case "Q", "QUEEN" ->
                    QUEEN;
                case "K", "KING" ->
                    KING;
                case "A", "ACE" ->
                    ACE;
                default ->
                    throw new IllegalArgumentException("No rank with symbol " + s);
            };
        }
    }

    private static final Map<Rank, Integer> RANK_VALUES = Map.of(
            Rank.SIX, 6, Rank.SEVEN, 7, Rank.EIGHT, 8, Rank.NINE, 9,
            Rank.TEN, 10, Rank.JACK, 11, Rank.QUEEN, 12, Rank.KING, 13,
            Rank.ACE, 14
    );

    private final Suit suit;
    private final Rank rank;
    private final ImageIcon icon;

    public Card(Suit suit, Rank rank, ImageIcon icon) {
        this.suit = Objects.requireNonNull(suit);
        this.rank = Objects.requireNonNull(rank);
        this.icon = icon;
    }

    public Suit getSuit() {
        return suit;
    }

    public Rank getRank() {
        return rank;
    }

    public ImageIcon getIcon() {
        return icon;
    }

    public int getRankValue() {
        return RANK_VALUES.get(rank);
    }

    public int compareTo(Card other, Suit trumpSuit) {
        if (this.suit.equals(other.suit)) {
            return Integer.compare(this.getRankValue(), other.getRankValue());
        }
        if (this.suit.equals(trumpSuit)) {
            return 1;
        }
        if (other.suit.equals(trumpSuit)) {
            return -1;
        }
        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Card card = (Card) obj;
        return suit == card.suit && rank == card.rank;
    }

    @Override
    public int hashCode() {
        return Objects.hash(suit, rank);
    }

    @Override
    public String toString() {
        return rank.getSymbol() + " " + suit.name().toLowerCase();
    }

    public String toNetworkString() {
        return suit.name().charAt(0) + ":" + rank.name().charAt(0);
    }

    public static Card fromNetworkString(String str, ImageIcon icon) {
        String[] parts = str.split(":");
        Suit suit = Suit.valueOf(parts[0] + parts[0].substring(1).toLowerCase());
        Rank rank = Rank.valueOf(parts[1] + parts[1].substring(1).toLowerCase());
        return new Card(suit, rank, icon);
    }
}
