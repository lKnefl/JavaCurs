package fool;

import java.util.*;

public class GameLogic {

    public enum RoundPhase {
        ATTACKING,
        DEFENDING,
        ADDING_CARDS,
        ROUND_ENDED
    }

    private int numPlayers = 2;
    private List<List<Card>> playersHands;
    private List<Card> deck;
    private List<Card> attackingCards;
    private List<Card> defendingCards;
    private RoundPhase currentPhase;

    private int currentPlayer;  // индекс атакующего
    private int defenderIndex;  // индекс защищающегося
    private Card.Suit trumpSuit;

    public GameLogic(int numPlayers, List<Card> fullDeck) {
        this.numPlayers = numPlayers;
        this.deck = new ArrayList<>(fullDeck);
        this.playersHands = new ArrayList<>();
        for (int i = 0; i < numPlayers; i++) {
            playersHands.add(new ArrayList<>());
        }
        this.attackingCards = new ArrayList<>();
        this.defendingCards = new ArrayList<>();
        this.currentPhase = RoundPhase.ATTACKING;
        this.currentPlayer = 0;
        this.defenderIndex = 1;
        this.trumpSuit = fullDeck.get(0).getSuit(); // берем козырь из первой карты колоды

        dealInitialCards();
    }

    private void dealInitialCards() {
        for (int i = 0; i < 6; i++) {
            for (List<Card> hand : playersHands) {
                if (!deck.isEmpty()) {
                    hand.add(deck.remove(deck.size() - 1));
                }
            }
        }
    }

    public Card.Suit getTrumpSuit() {
        return trumpSuit;
    }

    public List<Card> getPlayerHand(int playerId) {
        return playersHands.get(playerId);
    }

    public List<List<Card>> getPlayersHands() {
        return playersHands;
    }

    public List<Card> getDeck() {
        return deck;
    }

    public List<Card> getAttackingCards() {
        return attackingCards;
    }

    public List<Card> getDefendingCards() {
        return defendingCards;
    }

    public int getCurrentPlayer() {
        return currentPlayer;
    }

    public int getDefenderIndex() {
        return defenderIndex;
    }

    public RoundPhase getCurrentPhase() {
        return currentPhase;
    }

    public void setCurrentPhase(RoundPhase phase) {
        currentPhase = phase;
    }

    private void refillHands() {
        for (int i = 0; i < numPlayers; i++) {
            List<Card> hand = playersHands.get(i);
            while (hand.size() < 6 && !deck.isEmpty()) {
                hand.add(deck.remove(deck.size() - 1));
            }
        }
    }

    public boolean throwCards(int playerIndex, List<Card> cardsToThrow) {
        if (playerIndex != currentPlayer) {
            return false;
        }
        if (currentPhase != RoundPhase.ATTACKING && currentPhase != RoundPhase.ADDING_CARDS) {
            return false;
        }

        //if (!allCardsSameRank(cardsToThrow)) return false;
        if (!playersHands.get(playerIndex).containsAll(cardsToThrow)) {
            return false;
        }

        attackingCards.addAll(cardsToThrow);
        playersHands.get(playerIndex).removeAll(cardsToThrow);
        switchActivePlayerToOpponent();
        currentPhase = RoundPhase.DEFENDING;

        return true;
    }

    public boolean coverCard(int playerIndex, Card attackCard, Card defendCard) {
        if (playerIndex != defenderIndex) {
            return false;
        }
        if (currentPhase != RoundPhase.DEFENDING) {
            return false;
        }

        if (!attackingCards.contains(attackCard)) {
            return false;
        }
        if (defendingCards.size() >= attackingCards.size()) {
            return false;
        }

        if (!playersHands.get(playerIndex).contains(defendCard)) {
            return false;
        }

        if (!canCover(attackCard, defendCard)) {
            return false;
        }

        defendingCards.add(defendCard);
        playersHands.get(playerIndex).remove(defendCard);

        if (defendingCards.size() == attackingCards.size()) {
            // Все карты покрыты — переходим в фазу добавления карт
            currentPhase = RoundPhase.ADDING_CARDS;
            // Меняем активного игрока на атакующего (тот, кто подкидывает)
            //switchActivePlayerToOpponent();
        }

        return true;
    }

    public boolean canAddCards(List<Card> cardsToAdd) {
        if (currentPhase != RoundPhase.ADDING_CARDS) {
            return false;
        }
        if (cardsToAdd.isEmpty()) {
            return false;
        }

        // Проверяем, что все карты одного номинала
        if (!allCardsSameRank(cardsToAdd)) {
            return false;
        }

        // Получаем все номиналы на столе
        Set<Card.Rank> ranksOnTable = new HashSet<>();
        for (Card c : attackingCards) {
            ranksOnTable.add(c.getRank());
        }
        for (Card c : defendingCards) {
            ranksOnTable.add(c.getRank());
        }

        // Проверяем, что номинал карты для подкидывания есть на столе
        for (Card card : cardsToAdd) {
            if (!ranksOnTable.contains(card.getRank())) {
                return false;
            }
        }

        return true;
    }

    public boolean addCards(int playerIndex, List<Card> cardsToAdd) {
        if (playerIndex != currentPlayer) {
            return false;
        }
        if (!canAddCards(cardsToAdd)) {
            return false;
        }

        if (!playersHands.get(playerIndex).containsAll(cardsToAdd)) {
            return false;
        }

        attackingCards.addAll(cardsToAdd);
        playersHands.get(playerIndex).removeAll(cardsToAdd);

        // После добавления ход переходит защитнику
        currentPhase = RoundPhase.DEFENDING;
        currentPlayer = defenderIndex;

        return true;
    }

    public void takeCards(int playerIndex) {
        if (playerIndex != defenderIndex) {
            return;
        }

        List<Card> defenderHand = playersHands.get(playerIndex);

        defenderHand.addAll(attackingCards);
        defenderHand.addAll(defendingCards);

        attackingCards.clear();
        defendingCards.clear();

        refillHands();

        // После взятия ход переходит атакующему (без смены игроков)
        currentPhase = RoundPhase.ATTACKING;
    }

    public void endRound() {
        // Карты на столе убираются, руки добираются до 6 карт
        attackingCards.clear();
        defendingCards.clear();

        refillHands();

        // Сдвигаем текущего атакующего и защитника
        currentPlayer = (currentPlayer + 1) % numPlayers;
        defenderIndex = (currentPlayer + 1) % numPlayers;

        currentPhase = RoundPhase.ATTACKING;
    }

    public boolean isGameOver() {
        // Игра окончена, если колода пуста и у кого-то руки нет
        boolean deckEmpty = deck.isEmpty();
        long playersWithCards = playersHands.stream().filter(hand -> !hand.isEmpty()).count();

        return deckEmpty && playersWithCards <= 1;
    }

    private boolean allCardsSameRank(List<Card> cards) {
        if (cards.isEmpty()) {
            return false;
        }
        Card.Rank rank = cards.get(0).getRank();
        for (Card c : cards) {
            if (c.getRank() != rank) {
                return false;
            }
        }
        return true;
    }

    private boolean canCover(Card attackCard, Card defendCard) {
        if (defendCard.getSuit() == attackCard.getSuit() && defendCard.getRank().ordinal() > attackCard.getRank().ordinal()) {
            return true;
        }
        if (defendCard.getSuit() == trumpSuit && attackCard.getSuit() != trumpSuit) {
            return true;
        }
        return false;
    }

    public void switchActivePlayerToOpponent() {
        currentPlayer = (currentPlayer + 1) % 2;
    }
}
