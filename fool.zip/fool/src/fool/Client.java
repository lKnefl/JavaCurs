package fool;

import fool.Card.Rank;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.Socket;
import java.util.List;
import java.util.*;

public class Client extends JFrame {

    private JPanel attackPanel;
    private JPanel defensePanel;
    private JPanel playerHandPanel, tablePanel, controlsPanel;
    private JButton throwButton, coverButton, takeButton, passButton;
    private JTextArea logArea;
    private JLabel trumpCardLabel;
    private List<Card> playerHand = new ArrayList<>();
    private List<Card> selectedCards = new ArrayList<>();
    private List<Card> tableCards = new ArrayList<>();
    private int playerId;
    private PrintWriter out;
    private BufferedReader in;
    private Card.Suit trumpSuit;
    private boolean isDefending = false;
    private boolean isAdding = false;
    private boolean isMyTurn = false;
    private Map<String, ImageIcon> cardImages = new HashMap<>();
    private static final String ASSETS_PATH = "src/asset/";

    public Client() {
        System.out.println("Cards path: " + ASSETS_PATH);
        loadCardImages();
        initComponents();
        connectToServer();
    }

    private void loadCardImages() {
        Card.Suit[] suits = Card.Suit.values();
        Card.Rank[] ranks = Card.Rank.values();

        for (Card.Suit suit : suits) {
            for (Card.Rank rank : ranks) {
                try {
                    String filename = String.format("%s-card(%s).png",
                            suit.name().toLowerCase(),
                            rankToString(rank));

                    String fullPath = ASSETS_PATH + filename;

                    System.out.println("Loading: " + fullPath);

                    File file = new File(fullPath);
                    if (!file.exists()) {
                        System.err.println("File not found: " + fullPath);
                        continue;
                    }

                    ImageIcon originalIcon = new ImageIcon(file.toURI().toURL());
                    Image scaledImage = originalIcon.getImage()
                            .getScaledInstance(80, 120, Image.SCALE_SMOOTH);

                    String cardKey = String.format("%s_%s",
                            suit.name().toLowerCase(),
                            rankToString(rank));
                    cardImages.put(cardKey, new ImageIcon(scaledImage));

                    System.out.println("Success: " + filename);
                } catch (Exception e) {
                    System.err.printf("Error loading %s-card(%s).png: %s%n",
                            suit.name().toLowerCase(),
                            rankToString(rank),
                            e.getMessage());
                }
            }
        }

        try {
            String backFilename = "card-back.jpg";
            String backPath = ASSETS_PATH + backFilename;
            System.out.println("Loading back: " + backPath);

            File backFile = new File(backPath);
            if (backFile.exists()) {
                ImageIcon backIcon = new ImageIcon(backFile.toURI().toURL());
                Image scaledBack = backIcon.getImage()
                        .getScaledInstance(80, 120, Image.SCALE_SMOOTH);
                cardImages.put("back", new ImageIcon(scaledBack));
                System.out.println("Back loaded");
            } else {
                System.err.println("Back file not found, creating programmatically");

                BufferedImage img = new BufferedImage(80, 120, BufferedImage.TYPE_INT_RGB);
                Graphics2D g2d = img.createGraphics();

                g2d.setColor(new Color(0, 0, 139));
                g2d.fillRect(0, 0, 80, 120);

                g2d.setColor(Color.WHITE);
                g2d.setFont(new Font("Arial", Font.BOLD, 10));
                g2d.drawString("BACK", 10, 60);

                g2d.dispose();
                cardImages.put("back", new ImageIcon(img));
            }
        } catch (Exception e) {
            System.err.println("Error loading back: " + e.getMessage());
        }

        System.out.printf("Total loaded: %d images%n", cardImages.size());
    }

    private String rankToString(Card.Rank rank) {
        return switch (rank) {
            case SIX ->
                "6";
            case SEVEN ->
                "7";
            case EIGHT ->
                "8";
            case NINE ->
                "9";
            case TEN ->
                "10";
            case JACK ->
                "J";
            case QUEEN ->
                "Q";
            case KING ->
                "K";
            case ACE ->
                "A";
        };
    }

    private void initComponents() {
        setTitle("Durak Game");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        tablePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        tablePanel.setBackground(new Color(0, 100, 0));

        playerHandPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        playerHandPanel.setBackground(new Color(0, 100, 0));

        controlsPanel = new JPanel(new FlowLayout());
        controlsPanel.setBackground(new Color(240, 240, 240));

        trumpCardLabel = new JLabel("Trump: ");
        throwButton = new JButton("Throw");
        coverButton = new JButton("Cover");
        takeButton = new JButton("Take");
        passButton = new JButton("Pass");

        Font buttonFont = new Font("Arial", Font.BOLD, 14);
        throwButton.setFont(buttonFont);
        coverButton.setFont(buttonFont);
        takeButton.setFont(buttonFont);
        passButton.setFont(buttonFont);

        controlsPanel.add(trumpCardLabel);
        controlsPanel.add(throwButton);
        controlsPanel.add(coverButton);
        controlsPanel.add(takeButton);
        controlsPanel.add(passButton);

        logArea = new JTextArea(15, 30);
        logArea.setEditable(false);
        logArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(logArea);

        JScrollPane scrollPaneHand = new JScrollPane(playerHandPanel);
        scrollPaneHand.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);

        add(scrollPaneHand, BorderLayout.SOUTH);

        add(controlsPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        //add(playerHandPanel, BorderLayout.SOUTH);
        add(scrollPane, BorderLayout.EAST);

        throwButton.addActionListener(this::throwAction);
        coverButton.addActionListener(this::coverAction);
        takeButton.addActionListener(this::takeAction);
        passButton.addActionListener(this::passAction);

// Панели для карт атаки и защиты
        attackPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        defensePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));

        attackPanel.setOpaque(false);
        defensePanel.setOpaque(false);

// Убираем границы
        attackPanel.setBorder(null);
        defensePanel.setBorder(null);

// Добавим панели внутрь tablePanel вертикально
        JPanel container = new JPanel();
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
        container.setOpaque(false);

        container.add(attackPanel);
        container.add(defensePanel);

        tablePanel.add(container, BorderLayout.CENTER);

// Добавьте tablePanel в основной layout, например, как раньше:
        add(tablePanel, BorderLayout.CENTER);

        updateButtons(false);
    }

    private void throwAction(ActionEvent e) {
        if (!selectedCards.isEmpty()) {
            if (canThrowCard(selectedCards.get(0))) {
                StringBuilder move = new StringBuilder("THROW");
                for (Card card : selectedCards) {
                    move.append(":").append(card.getRank()).append(" ").append(card.getSuit());
                    logArea.append("Throwing card: " + card + "\n");
                }
                out.println(move.toString());
                selectedCards.clear();
                updateButtons(false);
            } else {
                logArea.append("Cannot throw - no cards with same rank on table!\n");
            }
        }
    }

    private boolean canThrowCard(Card card) {
        if (tableCards.isEmpty()) {
            return true;
        }

        String rankToMatch = card.getRank().name();
        for (Card tableCard : tableCards) {
            if (tableCard.getRank().name().equals(rankToMatch)) {
                return true;
            }
        }
        return false;
    }

    private void coverAction(ActionEvent e) {
        if (!selectedCards.isEmpty() && selectedCards.size() == 1) {
            Card card = selectedCards.get(0);
            logArea.append("Covering with: " + card + "\n");
            out.println("COVER:" + card.getRank() + " " + card.getSuit());
            selectedCards.clear();
            updateButtons(false);
        }
    }

    private void takeAction(ActionEvent e) {
        logArea.append("Taking cards\n");
        out.println("TAKE");
        selectedCards.clear();
        updateButtons(false);
    }

    private void passAction(ActionEvent e) {
        logArea.append("Passing\n");
        out.println("PASS");
        selectedCards.clear();
        updateButtons(false);
    }

    private void updateButtons(boolean myTurn) {
        isMyTurn = myTurn;
        boolean canThrow = myTurn && !selectedCards.isEmpty()
                && (tableCards.isEmpty() || canThrowCard(selectedCards.get(0)));
        boolean canCover = myTurn && isDefending && !selectedCards.isEmpty()
                && selectedCards.size() == 1;

        throwButton.setEnabled(canThrow);
        coverButton.setEnabled(canCover);
        takeButton.setEnabled(myTurn && isDefending);
        passButton.setEnabled(myTurn && isAdding);
    }

    private void connectToServer() {
        try {
            Socket socket = new Socket("localhost", 5555);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            new Thread(() -> {
                try {
                    String serverMessage;
                    while ((serverMessage = in.readLine()) != null) {
                        processServerMessage(serverMessage);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                    "Failed to connect to server",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    private void processServerMessage(String message) {
        SwingUtilities.invokeLater(() -> {
            logArea.append("Server: " + message + "\n");

            if (message.startsWith("PLAYER_ID:")) {
                playerId = Integer.parseInt(message.split(":")[1]);
                setTitle("Durak Game - Player " + playerId);
            } else if (message.startsWith("GAME_STARTED:")) {
                logArea.append("Game started with " + message.split(":")[1] + " players\n");
            } else if (message.startsWith("YOUR_HAND:")) {
                updateHand(message);
            } else if (message.startsWith("TURN:")) {
                String[] parts = message.split(":");
                int current = Integer.parseInt(parts[1]);
                isMyTurn = (current == playerId);
                isDefending = parts[2].equals("defense");
                isAdding = parts[2].equals("adding");
                updateButtons(isMyTurn);
                String phase;
                if (isDefending) {
                    phase = "defense";
                } else if (isAdding) {
                    phase = "add";
                } else {
                    phase = "attack";
                }
                if (isMyTurn) {
                    logArea.append("Your turn to " + phase + "\n");
                }
            } else if (message.startsWith("TRUMP:")) {
                trumpSuit = Card.Suit.valueOf(message.split(":")[1].toUpperCase());
                trumpCardLabel.setText("Trump: " + trumpSuit.toString().toLowerCase());
                ImageIcon trumpIcon = cardImages.get("back");
                if (trumpIcon != null) {
                    trumpCardLabel.setIcon(trumpIcon);
                }
            } else if (message.startsWith("TABLE:")) {
                updateTable(message);
            } else if (message.startsWith("GAME_OVER:")) {
                String winner = message.substring("GAME_OVER:".length());
                JOptionPane.showMessageDialog(this, "Игра окончена!\nПобедитель: " + winner,
                        "Game Over", JOptionPane.INFORMATION_MESSAGE);
                dispose(); // Закрываем окно клиента
                System.exit(0); // Завершаем приложение
            } else if (message.startsWith("PLAYER_THREW:")
                    || message.startsWith("PLAYER_COVERED:")
                    || message.startsWith("PLAYER_TOOK:")
                    || message.startsWith("PLAYER_PASSED:")) {
                // Эти сообщения уже записаны в лог
            } else if (message.startsWith("ERROR:")) {
                String errorMsg = message.substring(6);
                JOptionPane.showMessageDialog(this, errorMsg, "Error", JOptionPane.ERROR_MESSAGE);
                selectedCards.clear();
                updateButtons(true);
                logArea.append("Error received: " + errorMsg + ". Please choose another card.\n");
            }
        });
    }

    private void updateHand(String message) {
        playerHand.clear();
        String[] cards = message.substring(10).split(",");

        for (String cardStr : cards) {
            if (!cardStr.isEmpty()) {
                String[] parts = cardStr.trim().split(" ");
                if (parts.length == 2) {
                    try {
                        Card.Suit suit = Card.Suit.valueOf(parts[1].toUpperCase());
                        Card.Rank rank = Card.Rank.fromString(parts[0]); // Используем новый метод
                        String key = suit.name().toLowerCase() + "_" + rank.getSymbol();

                        ImageIcon icon = cardImages.get(key);
                        if (icon == null) {
                            icon = cardImages.get("back");
                            System.err.println("No image found for: " + key);
                        }
                        playerHand.add(new Card(suit, rank, icon));
                    } catch (IllegalArgumentException e) {
                        System.err.println("Invalid card: " + cardStr + " - " + e.getMessage());
                    }
                }
            }
        }
        showPlayerHand();
    }

    private void updateTable(String message) {
        // Очистить обе панели
        attackPanel.removeAll();
        defensePanel.removeAll();

        tableCards.clear(); // при необходимости

        // Удаляем префикс "TABLE:"
        String data = message.substring(6);

        // Разбиваем на атакующие и защищающие
        String[] parts = data.split("\\|", 2);
        String attackingPart = parts.length > 0 ? parts[0] : "";
        String defendingPart = parts.length > 1 ? parts[1] : "";

        // Парсим атакующие карты
        for (String cardStr : attackingPart.split(",")) {
            cardStr = cardStr.trim();
            if (!cardStr.isEmpty()) {
                try {
                    String[] cardParts = cardStr.split(" ");
                    if (cardParts.length == 2) {
                        Card.Rank rank = Card.Rank.fromString(cardParts[0]);
                        Card.Suit suit = Card.Suit.valueOf(cardParts[1].toUpperCase());
                        String key = suit.name().toLowerCase() + "_" + rank.getSymbol();
                        ImageIcon icon = cardImages.get(key);
                        if (icon != null) {
                            JLabel cardLabel = new JLabel(icon);
                            attackPanel.add(cardLabel);
                            tableCards.add(new Card(suit, rank, icon));
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Invalid attacking card: " + cardStr + " - " + e.getMessage());
                }
            }
        }
        int numCardsAtk = attackingPart.isEmpty() ? 0 : attackingPart.split(",").length;
        int numCardsDef = defendingPart.isEmpty() ? 0 : defendingPart.split(",").length;
        int shiftPx = 0;
        if (numCardsDef > 1) {
            shiftPx = (numCardsAtk - numCardsDef) * 50;  // Настраиваем под себя
        }

        defensePanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        defensePanel.add(Box.createRigidArea(new Dimension(shiftPx, 0)), 0);
        // Парсим защищающие карты
        for (String cardStr : defendingPart.split(",")) {
            cardStr = cardStr.trim();
            if (!cardStr.isEmpty()) {
                try {
                    String[] cardParts = cardStr.split(" ");
                    if (cardParts.length == 2) {
                        Card.Rank rank = Card.Rank.fromString(cardParts[0]);
                        Card.Suit suit = Card.Suit.valueOf(cardParts[1].toUpperCase());
                        String key = suit.name().toLowerCase() + "_" + rank.getSymbol();
                        ImageIcon icon = cardImages.get(key);
                        if (icon != null) {
                            JLabel cardLabel = new JLabel(icon);
                            defensePanel.add(cardLabel);
                            tableCards.add(new Card(suit, rank, icon));
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Invalid defending card: " + cardStr + " - " + e.getMessage());
                }
            }
        }

        // Обновляем отображение
        attackPanel.revalidate();
        attackPanel.repaint();

        defensePanel.revalidate();
        defensePanel.repaint();

        tablePanel.revalidate();
        tablePanel.repaint();
    }

    private void showPlayerHand() {
        playerHandPanel.removeAll();
        selectedCards.clear();

        for (Card card : playerHand) {
            JLabel cardLabel = new JLabel(card.getIcon());
            cardLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            cardLabel.setBorder(null); // Убираем рамку по умолчанию

            final boolean[] isSelected = {false};

            cardLabel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (isSelected[0]) {
                        cardLabel.setBorder(null);
                        selectedCards.remove(card);
                        isSelected[0] = false;
                    } else {
                        if (isAdding) {
                            // Разрешаем выбирать только карты, которые есть на столе по номиналу
                            boolean canSelect = false;
                            for (Card tableCard : tableCards) {
                                if (tableCard.getRank() == card.getRank()) {
                                    canSelect = true;
                                    break;
                                }
                            }
                            if (!canSelect) {
                                // Можно вывести сообщение об ошибке или просто игнорировать
                                return;
                            }
                        } else // Проверка одного номинала (если нужно)
                        if (!selectedCards.isEmpty()) {
                            Rank currentRank = selectedCards.get(0).getRank();
                            if (card.getRank() != currentRank) {
                                // Можно вывести сообщение об ошибке
                                return;
                            }
                        }
                        cardLabel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 2));
                        selectedCards.add(card);
                        isSelected[0] = true;
                    }

                    // Обновляем состояние кнопок в зависимости от хода
                    if (isAdding) {
                        passButton.setEnabled(true);
                    } else {
                        passButton.setEnabled(false);
                    }
                    if (!isDefending) {
                        throwButton.setEnabled(!selectedCards.isEmpty());
                        coverButton.setEnabled(false);
                    } else {
                        coverButton.setEnabled(!selectedCards.isEmpty());
                        throwButton.setEnabled(false);
                    }

                    playerHandPanel.revalidate();
                    playerHandPanel.repaint();
                }
            });

            playerHandPanel.add(cardLabel);
        }

        playerHandPanel.revalidate();
        playerHandPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Client client = new Client();
            client.setVisible(true);
        });
    }
}
