/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fool;

public class Launcher {
    public static void main(String[] args) {
        // Запуск сервера в отдельном потоке
        new Thread(() -> {
            Server.main(new String[0]); // Замените `Server` на ваш класс сервера
        }).start();

        // Ждем, чтобы сервер успел запуститься
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Запуск первого клиента
        new Thread(() -> {
            Client.main(new String[0]); // Замените `Client` на ваш класс клиента
        }).start();

        // Запуск второго клиента
        new Thread(() -> {
            Client.main(new String[0]); // Повторно запускаем клиент
        }).start();
    }
}