package fool;

import java.io.*;
import java.net.*;
import java.util.*;

public class Server {

    private static final int PORT = 5555;
    static List<ClientHandler> clients = new ArrayList<>();
    private static GameLogic gameLogic;
    private static List<Card> fullDeck;

    public static void main(String[] args) {
        System.out.println("Server started. Waiting for connections...");
        initDeck();

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("New connection from: " + socket.getInetAddress());

                ClientHandler clientThread = new ClientHandler(socket);
                clients.add(clientThread);
                clientThread.start();

                if (clients.size() >= 2) {
                    startGame();
                }
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }

    private static void initDeck() {
        fullDeck = new ArrayList<>();
        Card.Suit[] suits = Card.Suit.values();
        Card.Rank[] ranks = Card.Rank.values();

        for (Card.Suit suit : suits) {
            for (Card.Rank rank : ranks) {
                fullDeck.add(new Card(suit, rank, null));
            }
        }
        Collections.shuffle(fullDeck);
        System.out.println("Deck initialized with " + fullDeck.size() + " cards");
    }

    private static void startGame() {
        System.out.println("Starting game with " + clients.size() + " players");
        gameLogic = new GameLogic(clients.size(), fullDeck);

        broadcast("TRUMP:" + gameLogic.getTrumpSuit());
        broadcast("GAME_STARTED:" + clients.size());

        for (int i = 0; i < clients.size(); i++) {
            clients.get(i).setPlayerId(i);
            clients.get(i).sendMessage("PLAYER_ID:" + (i));
            sendHand(i);
            System.out.println("Player " + (i) + " initialized");
        }

        broadcastTurnInfo();
    }

    private static void broadcastTurnInfo() {
        int current = gameLogic.getCurrentPlayer();
        String phase;
        if (gameLogic.getCurrentPhase() == GameLogic.RoundPhase.ATTACKING) {
            phase = "attack";
        } else if (gameLogic.getCurrentPhase() == GameLogic.RoundPhase.ADDING_CARDS) {
            phase = "adding";
        } else {
            phase = "defense";
        }
        String message = "TURN:" + current + ":" + phase;
        System.out.println("Broadcasting turn info: " + message);
        broadcast(message);
    }

    public static void broadcast(String message) {
        System.out.println("Broadcasting: " + message);
        for (ClientHandler client : clients) {
            client.sendMessage(message);
        }
    }

    public static void sendHand(int playerId) {
        StringBuilder hand = new StringBuilder("YOUR_HAND:");
        for (Card card : gameLogic.getPlayerHand(playerId)) {
            // Используем toString(), который возвращает "8 spade" вместо "EIGHT spade"
            hand.append(card).append(",");
        }
        System.out.println("Sending hand to player " + (playerId) + ": " + hand);
        clients.get(playerId).sendMessage(hand.toString());
    }

    public static void updateTable() {
        StringBuilder table = new StringBuilder("TABLE:");

        List<Card> attacking = gameLogic.getAttackingCards();
        List<Card> defending = gameLogic.getDefendingCards();

        for (Card card : attacking) {
            table.append(card.toString()).append(",");
        }

        table.append("|");

        for (Card card : defending) {
            table.append(card.toString()).append(",");
        }

        System.out.println("Updating table: " + table);
        broadcast(table.toString());
    }

    public static synchronized void processMove(int playerId, String move) {
        int playerIndex = playerId;
        String[] parts = move.split(":");
        String command = parts[0];

        try {
            switch (command) {
                case "THROW":
                    if (gameLogic.getCurrentPhase() == GameLogic.RoundPhase.DEFENDING) {
                        clients.get(playerIndex).sendMessage("ERROR:Not your turn to THROW");
                        return;
                    }
                    List<Card> throwCards = new ArrayList<>();
                    for (int i = 1; i < parts.length; i++) {
                        String[] cardData = parts[i].split(" ");
                        Card.Suit suit = Card.Suit.valueOf(cardData[1].toUpperCase());
                        Card.Rank rank = Card.Rank.fromString(cardData[0]);
                        throwCards.add(new Card(suit, rank, null));
                    }
                    if (gameLogic.throwCards(playerIndex, throwCards)) {
                        broadcast("PLAYER_THREW:" + playerId + ":" + throwCards);
                        updateTable();
                        broadcastTurnInfo();

                    }
                    break;

                case "COVER":
                    if (gameLogic.getCurrentPhase() != GameLogic.RoundPhase.DEFENDING) {
                        clients.get(playerIndex).sendMessage("ERROR:Not your turn to COVER");
                        return;
                    }
                    String[] defendData = parts[1].split(" ");
                    if (defendData.length < 2) {
                        clients.get(playerId).sendMessage("ERROR:Invalid card format in COVER");
                        return;
                    }
                    Card defendCard = new Card(
                            Card.Suit.valueOf(defendData[1].toUpperCase()),
                            Card.Rank.fromString(defendData[0]),
                            null
                    );
                    Card attackCard = gameLogic.getAttackingCards().get(gameLogic.getDefendingCards().size());

                    if (gameLogic.coverCard(playerIndex, attackCard, defendCard)) {
                        broadcast("PLAYER_COVERED:" + playerId + ":" + defendCard);
                        updateTable();
                        if (gameLogic.getDefendingCards().size() == gameLogic.getAttackingCards().size()) {
                            gameLogic.setCurrentPhase(GameLogic.RoundPhase.ADDING_CARDS);
                            gameLogic.switchActivePlayerToOpponent();
                            broadcast("PHASE:ADDING_CARDS");
                        }
                        broadcastTurnInfo();
                    } else {
                        clients.get(playerIndex).sendMessage("ERROR:Invalid cover move");
                    }
                    break;

                case "ADD_CARDS":
                    if (gameLogic.getCurrentPhase() != GameLogic.RoundPhase.ADDING_CARDS) {
                        clients.get(playerIndex).sendMessage("ERROR:Not your turn to ADD_CARDS");
                        return;
                    }
                    List<Card> addCards = new ArrayList<>();
                    for (int i = 1; i < parts.length; i++) {
                        String[] cardData = parts[i].split(" ");
                        Card.Suit suit = Card.Suit.valueOf(cardData[1].toUpperCase());
                        Card.Rank rank = Card.Rank.fromString(cardData[0]);
                        addCards.add(new Card(suit, rank, null));
                    }
                    if (gameLogic.addCards(playerIndex, addCards)) {
                        broadcast("PLAYER_ADDED:" + playerId + ":" + addCards);
                        updateTable();
                        // После добавления ход возвращается защитнику
                        gameLogic.setCurrentPhase(GameLogic.RoundPhase.DEFENDING);
                        gameLogic.switchActivePlayerToOpponent();
                        broadcastTurnInfo();
                    } else {
                        clients.get(playerIndex).sendMessage("ERROR:Failed to add cards");
                    }
                    break;

                case "PASS":
                    if (gameLogic.getCurrentPhase() != GameLogic.RoundPhase.ADDING_CARDS) {
                        clients.get(playerIndex).sendMessage("ERROR:Not your turn to PASS");
                        return;
                    }
                    gameLogic.endRound();
                    broadcast("ROUND_ENDED");
                    updateTable();
                    broadcastTurnInfo();
                    break;

                case "TAKE":
                    if (playerIndex != gameLogic.getDefenderIndex()) {
                        clients.get(playerIndex).sendMessage("ERROR:Not your turn to TAKE");
                        return;
                    }
                    gameLogic.takeCards(playerIndex);
                    broadcast("PLAYER_TAKE:" + playerId);
                    updateTable();
                    gameLogic.endRound();
                    broadcast("ROUND_ENDED");
                    broadcastTurnInfo();
                    break;

                default:
                    clients.get(playerIndex).sendMessage("ERROR:Unknown command");
            }
        } catch (Exception e) {
            clients.get(playerIndex).sendMessage("ERROR:" + e.getMessage());
        }

        updateAllHands();

        if (gameLogic.isGameOver()) {
            checkGameOver();
        }
    }

    private static void endRound() {
        System.out.println("Ending round");
        broadcast("ROUND_ENDED");
        gameLogic.endRound();
        updateTable();
        updateAllHands();
        broadcastTurnInfo();
        if (gameLogic.isGameOver()) {
            checkGameOver();
        }
    }

    private static void checkGameOver() {
        boolean gameOver = false;
        String reason = "";

        boolean deckEmpty = gameLogic.getDeck().isEmpty();
        long playersWithCards = gameLogic.getPlayersHands().stream()
                .filter(hand -> !hand.isEmpty())
                .count();

        if (deckEmpty && playersWithCards <= 1) {
            gameOver = true;
            List<List<Card>> playersHands = gameLogic.getPlayersHands();
            for (int i = 0; i < playersHands.size(); i++) {
                if (playersHands.get(i).isEmpty()) {
                    reason = "Игрок " + i;
                }
            }
        }
        if (playersWithCards == 0) {
            gameOver = true;
            reason = "Ничья";
        }

        if (gameOver) {
            broadcast("GAME_OVER:" + reason);
            for (ClientHandler client : clients) {
                client.closeConnection();
            }
            clients.clear();
            System.out.println("Game over: " + reason);
        }
    }

    private static void updateAllHands() {
        System.out.println("Updating all hands");
        for (int i = 0; i < clients.size(); i++) {
            sendHand(i);
        }
    }

    public static synchronized void removeClient(ClientHandler client) {
        System.out.println("Removing client: " + client.getPlayerId());
        clients.remove(client);
        if (clients.size() < 2) {
            System.out.println("Not enough players, game cannot continue");
            broadcast("GAME_OVER:Not enough players");
        }
    }
}

class ClientHandler extends Thread {

    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private int playerId;

    public ClientHandler(Socket socket) {
        this.socket = socket;
        try {
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            System.err.println("Error creating client handler: " + e.getMessage());
        }
    }

    public void setPlayerId(int id) {
        this.playerId = id;
    }

    public int getPlayerId() {
        return playerId;
    }

    public void closeConnection() {
        try {
            socket.close();
        } catch (IOException e) {
            System.err.println("Err closing socket " + playerId + ": " + e.getMessage());
        }
    }

    public void run() {
        try {
            System.out.println("Player " + playerId + " handler started");
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                System.out.println("Received from player " + playerId + ": " + inputLine);
                Server.processMove(playerId, inputLine);
            }
        } catch (IOException e) {
            System.out.println("Player " + playerId + " disconnected");
        } finally {
            Server.removeClient(this);
            try {
                socket.close();
            } catch (IOException e) {
                System.err.println("Error closing socket: " + e.getMessage());
            }
        }
    }

    public void sendMessage(String msg) {
        out.println(msg);
    }
}
